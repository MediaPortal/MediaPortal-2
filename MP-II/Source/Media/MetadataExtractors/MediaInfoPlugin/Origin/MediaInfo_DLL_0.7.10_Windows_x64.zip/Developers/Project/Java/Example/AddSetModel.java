﻿package hdtvp;

import javax.swing.table.*;
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class AddSetModel extends AbstractTableModel{
	
	static String[] col = {"no.","Suffix","Artist","Songs","Talk","Date","TV station","Program","Duration","Resolution","Filesize","ptsinfo","Date added","new name","old name","rare"};
	static Object[][] newData;
	
	public AddSetModel(){
		newData = new Object[AddNew.newFile.size()][16];
		int inilength;
		try{
			inilength = LoadProject.allfile.length+1;
		}catch(Exception e){
			inilength = 0;
		}
		for(int i=0;i<AddNew.newFile.size();i++){
			for(int j=0;j<16;j++){
				if(j==0)
					newData[i][j] = String.format("%04d", inilength+i);
				else if(j==1||j==8||j==9||j==10){
					try{
						newData[i][j] =  getFileData(j,"F:\\Japanese\\"+AddNew.dir[i]);
					}catch(Exception e){}
				}else if(j==14){
					newData[i][j] = AddNew.dir[i];
				}else if(j==4){
					newData[i][j] =  new Boolean(false);
				}else if(j==11||j==13||j==15){
					newData[i][j] =  "";
				}else if(j==12){
			        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
					Date date = new Date();
					newData[i][j] = dateFormat.format(date).toString();
				}else{
					String cellvalue = "";
					for(int k=0;k<AddNew.changed.size();k++){
						if(getChangedValue(k)[0]==i){
							if(getChangedValue(k)[2]==1&&j==2){
								cellvalue += " " + (String)(getNewFileValue(i)[getChangedValue(k)[1]]);
							}else if(getChangedValue(k)[2]==2&&j==3){
								cellvalue += " " + (String)(getNewFileValue(i)[getChangedValue(k)[1]]);
							}else if(getChangedValue(k)[2]==3&&j==5){
								cellvalue += " " + (String)(getNewFileValue(i)[getChangedValue(k)[1]]);
							}else if(getChangedValue(k)[2]==4&&j==6){
								cellvalue += " " + (String)(getNewFileValue(i)[getChangedValue(k)[1]]);
							}else if(getChangedValue(k)[2]==5&&j==7){
								cellvalue += " " + (String)(getNewFileValue(i)[getChangedValue(k)[1]]);
							}
						}			
					}
					newData[i][j] = cellvalue;
				}
				//System.out.println(newData[i][j]);
			}
		}
		
	}
	
	public Object getValueAt(int r, int c){
		if(c==13){
			return newName(r);
		}
		return newData[r][c];
	}
	
	public int[] getChangedValue(int i){
		return (int[])AddNew.changed.elementAt(i);
	}
	
	public Object[] getNewFileValue(int i){
		return (Object[])AddNew.newFile.elementAt(i);
	}
	
	public String getFileData(int mode,String name) throws Exception{
		
		MediaInfo mi = new MediaInfo();
		String returnval="";

		if (mi.Open(name)>0){
			if(mode==10){
				returnval = mi.Get(MediaInfo.Stream_General, 0, "FileSize", MediaInfo.Info_Text, MediaInfo.Info_Name);
			}else if(mode==9){
				returnval = mi.Get(MediaInfo.Stream_Video, 0, "Width", MediaInfo.Info_Text, MediaInfo.Info_Name) + "x" + mi.Get(MediaInfo.Stream_Video, 0, "Height", MediaInfo.Info_Text, MediaInfo.Info_Name);
			}else if(mode==8){
				returnval = mi.Get(MediaInfo.Stream_Video, 0, "Duration/String2",MediaInfo.Info_Text, MediaInfo.Info_Name);
			}
			else if(mode==1){
				returnval = mi.Get(MediaInfo.Stream_General, 0, "Format", MediaInfo.Info_Text, MediaInfo.Info_Name);
			}
		}
		mi.Close();
		return returnval;

	}
	
	public Object newName(int r){
		
		//[r][1]=Format
		//[r][2]=Artist
		//[r][5]=Date
		//[r][3]=Song
		//[r][4]=Talk
		//[r][6]=TVstation
		//[r][7]=Program
		//[r][8]=Duration
		//[r][9]=Resolution

		
		String newName = "";
		if(newData[r][1].equals("TS")){
			newName += "[HDTV-TS]";
		}
		else if(!"".equals(newData[r][1])){
			newName += "[HDTV]";
		}
		
		if(!newData[r][2].equals("")){
			newName += " "+newData[r][2];
		}
		
		if(!newData[r][5].equals("")){
			newName += " - ["+newData[r][5]+"] -";
		}else{
			newName += " -";
		}
		
		if(!newData[r][3].equals("")){
			newName += " "+newData[r][3];
		}
		
		if(Boolean.TRUE.equals(newData[r][4])){
			newName += " + トーク";
		}
		
		if(!newData[r][6].equals("")||!newData[r][7].equals("")||!newData[r][8].equals("")||!newData[r][9].equals("")){
			newName += " (";
		}
		
		if(!newData[r][6].equals("")){
			newName += newData[r][6] + " ";
		}
		
		if(!newData[r][7].equals("")){
			newName += newData[r][7] + " ";
		}
		
		if(!newData[r][8].equals("")){
			newName += "- "+newData[r][8];
		}
		
		if(!newData[r][9].equals("")){
			newName += " "+newData[r][9];
		}
		if(!newData[r][6].equals("")||!newData[r][7].equals("")||!newData[r][8].equals("")||!newData[r][9].equals("")){
			newName += ")";
		}
		
		if("TS".equals(newData[r][1]))
			newName += ".ts";
		else if("MPEG2 Transport".equals(newData[r][1]))
			newName += ".m2t";
		else if("AVI".equals(newData[r][1]))
			newName += ".avi";
		else if("DIVX".equals(newData[r][1]))
			newName += ".divx";
		else if("MP4".equals(newData[r][1]))
			newName += ".mp4";
		else if("Real Media VBR".equals(newData[r][1]))
			newName += ".rmvb";
		else if("other".equals(newData[r][1]))
			newName += GetCondition.getExtension(new File(AddNew.dir[r]));

		
		return newName;
	}

	
	public int getRowCount(){
		return AddNew.newFile.size();
	}
	
	public int getColumnCount(){
		return newData[0].length;
	}
	
	public String getColumnName(int c){
		return col[c];
	}
	
	public Class getColumnClass(int c){
		try{
			return newData[0][c].getClass();
		}catch(Exception e){
			return col.getClass();
		}
	}
	
	public void setValueAt(Object obj, int r, int c){
		newData[r][c] = obj;
		if(c!=13){
			newData[r][13] = newName(r);
			AddNew.setTable.changeSelection(r, 13, false, false);
		}
	}
	
	public boolean isCellEditable(int r, int c){
		return true;
	}
}
